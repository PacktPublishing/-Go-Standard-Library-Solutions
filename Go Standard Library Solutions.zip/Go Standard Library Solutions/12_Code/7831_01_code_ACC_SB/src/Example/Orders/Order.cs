using System.Collections.Generic;
using Example.Products;

namespace Example.Orders
{
    public class Order
    {
        public int Id { get; set; }
        public virtual List<Product> Products { get; set; } = new List<Product>();
        public int AccountId { get; set; }

        public bool IsValid()
        {
            return Products.Count > 0;
        }
    }
}
