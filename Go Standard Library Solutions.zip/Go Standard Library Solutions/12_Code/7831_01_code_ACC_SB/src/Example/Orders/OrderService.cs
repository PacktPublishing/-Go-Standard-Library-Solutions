using Example.Shipments;

namespace Example.Orders
{
    public class OrderService : IOrderService
    {
        private readonly IShipmentService _shipmentService;

        public OrderService(IShipmentService shipmentService) 
        {
            _shipmentService = shipmentService;
        }

        /// <summary>
        /// Creates the order in the database and begins
        /// processing.
        /// </summary>
        public OrderStatus CreateOrder(Order order)
        {
            if(order.IsValid() == false)
            {
                return OrderStatus.Incomplete;
            }

            // ... 
            // save the order to the database
            // ...

            _shipmentService.QueueShipment(order);

            return OrderStatus.Processing;
        }
    }
}
