namespace Example.Orders
{
    public interface IOrderService
    {
        OrderStatus CreateOrder(Order order);
    }
}
