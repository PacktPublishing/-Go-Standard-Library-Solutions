namespace Example.Orders
{
    public enum OrderStatus
    {
        Incomplete,
        Processing,
        Shipped,
        Complete
    }
}
