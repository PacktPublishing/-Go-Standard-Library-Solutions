using Example.Orders;

namespace Example.Shipments
{
    public interface IShipmentService
    {
        void QueueShipment(Order order);
    }
}
