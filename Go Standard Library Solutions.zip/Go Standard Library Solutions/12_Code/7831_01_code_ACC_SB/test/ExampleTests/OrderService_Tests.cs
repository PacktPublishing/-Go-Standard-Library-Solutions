using System;
using Example.Orders;
using Example.Shipments;
using Xunit;

namespace ExampleTests
{
    public class OrderService_Tests
    {
        [Fact]
        public void CreateOrder_Returns_Incomplete_Order_Status_If_Order_IsInvalid()
        {
            // arrange
            var order = new Order();
            var orderService = new OrderService(new ShipmentService_Stub());

            // act
            var result = orderService.CreateOrder(order);

            // assert
            Assert.Equal(OrderStatus.Incomplete, result);
        }
    }

    class ShipmentService_Stub : IShipmentService
    {
        public void QueueShipment(Order order)
        { }
    }
}
