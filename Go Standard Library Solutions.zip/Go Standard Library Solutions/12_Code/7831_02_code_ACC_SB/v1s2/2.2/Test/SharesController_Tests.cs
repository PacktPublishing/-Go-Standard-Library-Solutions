using Xunit;

namespace Test
{
    public class SharesController_Tests
    {
        [Fact]
        public void Post_Sends_A_Tweet()
        {
            // arrange
            var twitterService = new TwitterServiceStub();
            var controller = new SharesController(twitterService);
            var share = new Share {
                Message = string.Empty
            };

            // act
            var result = controller.Post(share);

            // assert
            Assert.Equal(1, twitterService.TweetCount);
            Assert.Equal(200, result);
        }
    }
}
