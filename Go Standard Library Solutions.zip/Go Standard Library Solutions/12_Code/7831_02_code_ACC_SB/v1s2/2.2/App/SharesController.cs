public class SharesController
{
    private readonly ITwitterService _twitter;

    public SharesController(
        ITwitterService twitter)
    {
        _twitter = twitter;
    }

    public int Post(Share share)
    {
        _twitter.Tweet(share.Message);
        return 200;
    }
}