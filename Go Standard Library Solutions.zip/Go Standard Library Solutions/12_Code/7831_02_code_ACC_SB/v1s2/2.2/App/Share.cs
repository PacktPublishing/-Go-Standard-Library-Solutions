public class Share
{
    public string Message { get; set; }
}