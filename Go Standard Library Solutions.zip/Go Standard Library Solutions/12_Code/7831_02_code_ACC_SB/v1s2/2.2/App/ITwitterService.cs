using System;

public interface ITwitterService {
    void Tweet(string message);
}

public class TwitterServiceStub 
: ITwitterService
{
    public int TweetCount { get; set; }
    public void Tweet(string message)
    {
        TweetCount += 1;
    }
}