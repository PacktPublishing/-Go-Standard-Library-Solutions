public class Calculator
{
    public int Add(int x, int y) {
        return x + y;
    }
}