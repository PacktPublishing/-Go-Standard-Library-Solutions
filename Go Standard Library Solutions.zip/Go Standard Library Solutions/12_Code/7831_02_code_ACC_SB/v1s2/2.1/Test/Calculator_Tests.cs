using Xunit;

namespace Test
{
    public class Calculator_Tests
    {
        [Theory]
        [InlineData(1, 2, 3)]
        [InlineData(2, 2, 4)]
        public void Add_Sums_Numbers(int x, int y, int expected)
        {
            // arrange
            var calculator = new Calculator();

            // act
            var result = calculator.Add(x, y);

            // assert
            Assert.Equal(expected, result);
        }
    }
}
