using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using App;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.TestHost;
using Newtonsoft.Json;
using Xunit;

namespace Test.Acceptance
{
    public class OrderStatusCodes_Tests
    {
        [Fact]
        public async Task Can_Get_OrderStatusCodesAsync()
        {
            // arrange
            var builder = new WebHostBuilder()
                .UseStartup<Startup>();
            var server = new TestServer(builder);
            var client = server.CreateClient();
            var method = new HttpMethod("GET");
            const string uri = "/api/orderStatusCodes";
            var request = new HttpRequestMessage(method, uri);

            // act
            var response = await client.SendAsync(request);
            var body = await response.Content.ReadAsStringAsync();
            var orderStatusCodes = JsonConvert
                .DeserializeObject<List<string>>(body);

            // assert
            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
            Assert.Equal(3, orderStatusCodes.Count);
        }
    }
}
