using Xunit;

namespace Test.Unit
{
    public class OrderStatusCodes_Tests
    {
        [Fact]
        public void GetOrderStatusCodes_Returns_Correct_Codes()
        {   
            // arrange
            var service = new OrderStatusCodeService();

            // act
            var result = service.GetOrderStatusCodes();

            // assert
            Assert.Contains("OrderPlaced", result);
            Assert.Contains("OrderFailed", result);
            Assert.Contains("OrderFulfilled", result);
        }
    }
}
