using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Xunit;

namespace Test.Integration
{
    public class OrderStatusCodes_Tests
    {
        [Fact]
        public void Get_Returns_List_Of_StatusCodes()
        {
            // arrange
            var service = new OrderStatusCodeService();
            var controller = new OrderStatusCodesController(service);

            // act
            var result = controller.Get();

            // assert
            Assert.NotNull(result);
            var objectResult = Assert.IsType<OkObjectResult>(result);

            var list = Assert.IsType<List<string>>(objectResult.Value);
            Assert.Equal(3, list.Count);
        }
    }
}
