using System.Collections.Generic;

public interface IOrderStatusCodeService
{
    List<string> GetOrderStatusCodes();
}