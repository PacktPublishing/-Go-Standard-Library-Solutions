using System;
using Microsoft.AspNetCore.Mvc;

[Route("api/[controller]")]
public class OrderStatusCodesController : Controller
{
    private readonly IOrderStatusCodeService _orderStatusCodes;

    public OrderStatusCodesController(IOrderStatusCodeService orderStatusCodes)
    {
        _orderStatusCodes = orderStatusCodes;
    }

    [HttpGet]
    public IActionResult Get()
    {
        var statusCodes = _orderStatusCodes.GetOrderStatusCodes();
        return Ok(statusCodes);
    }
}