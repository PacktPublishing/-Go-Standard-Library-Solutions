using System;
using System.Collections.Generic;

public class OrderStatusCodeService : IOrderStatusCodeService
{
    private List<string> _codes = new List<string> {
        "OrderPlaced",
        "OrderFailed",
        "OrderFulfilled"
    };

    public List<string> GetOrderStatusCodes()
    {
        return _codes;
    }
}